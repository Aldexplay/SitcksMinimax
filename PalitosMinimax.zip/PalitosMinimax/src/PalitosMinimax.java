
import java.util.Scanner;


public class PalitosMinimax {
   
	 															// Método principal para jugar 
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int palitos = 21; 									// Cantidad inicial de palitos en caso de querer editar el tamaño de palitos , editar aqui

        while (true) {										//mientras sea true o valido
            mostrarPalitos(palitos);

            														// Turno del jugador 1
            int palitosQuitados = turnoJugador(scanner, palitos);
            palitos -= palitosQuitados;

            if (verificarDerrota(palitos)) {
                System.out.println("¡Has perdido! La IA gana.");
                break;
            }

            mostrarPalitos(palitos);							//mostrar palitos 

            													// Turno de la IA
            System.out.println(" Turno de la IA ...");
            palitosQuitados = turnoIA(palitos);
            System.out.println(" La IA quitó " + palitosQuitados + " palitos");
            palitos -= palitosQuitados;

            if (verificarDerrota(palitos)) {
                System.out.println("¡Felicidades! Has ganado El juego.");
                break;
            }
        }

        scanner.close();
    }
	
	
	
																// Método para mostrar el estado actual de los palitos
    public static void mostrarPalitos(int palitos) {
        System.out.println("Palitos restantes: " + palitos);
        for (int i = 0; i < palitos; i++) {
            System.out.print("| ");
        }
        System.out.println();
        System.out.println();
    }

    															// Método para verificar si el jugador perdió (es decir, si no quedan palitos)
    public static boolean verificarDerrota(int palitos) {
        return palitos <= 0;
    }

    																		// Método de instrucciones para que el jugador realice un movimiento
    public static int turnoJugador(Scanner scanner, int palitos) {
        System.out.print("Elige la cantidad de palitos a quitar (1, 2 o 3): ");
        int palitosQuitados = scanner.nextInt();

        																			// Verificar si la cantidad de palitos es válida
        while (palitosQuitados < 1 || palitosQuitados > 3 || palitosQuitados > palitos) {
            System.out.println("Movimiento inválido. Inténtalo de nuevo.");
            System.out.print("Elige la cantidad de palitos a quitar (1, 2 o 3): ");
            palitosQuitados = scanner.nextInt();
        }

        return palitosQuitados;
    }

    																		// Método Minimax para determinar el mejor movimiento para la IA
    public static int minimax(int palitos, int profundidad, boolean jugadorMaximizador) {
    																	// Verificar si se alcanzó la profundidad máxima o no quedan más palitos
    	if (profundidad == 0 || palitos <= 0) {
            return (jugadorMaximizador) ? -1 : 1;
        }

        if (jugadorMaximizador) {
            int mejorValor = Integer.MIN_VALUE;							// Inicializar el mejor valor como el valor más bajo posible

            															// Iterar sobre los movimientos posibles (eliminar de 1 a 3 palitos)
            for (int i = 1; i <= 3; i++) {
                if (i <= palitos) {
                    int valor = minimax(palitos - i, profundidad - 1, false);// Calcular el valor del movimiento actual recursivamente
                    mejorValor = Math.max(mejorValor, valor);			// Actualizar el mejor valor encontrado hasta ahora
                
                }
            }

            return mejorValor;		 // Devolver el mejor valor encontrado
        } else {
            int mejorValor = Integer.MAX_VALUE;						// Inicializar el mejor valor como el valor más alto posible
            
            													// Iterar sobre los movimientos posibles (eliminar de 1 a 3 palitos)
            for (int i = 1; i <= 3; i++) {
            													// Calcular el valor del movimiento actual recursivamente
            	if (i <= palitos) {
                    int valor = minimax(palitos - i, profundidad - 1, true);
                    mejorValor = Math.min(mejorValor, valor);
                }
            }

            return mejorValor;
        }
    }

    																		// Método para que la IA realice un movimiento utilizando el algoritmo Minimax
    public static int turnoIA(int palitos) {
        int mejorMovimiento = 0;
        int mejorValor = Integer.MIN_VALUE;

        for (int i = 1; i <= 3; i++) {
            if (i <= palitos) {
                int valor = minimax(palitos - i, 9, false);
                if (valor > mejorValor) {
                    mejorValor = valor;
                    mejorMovimiento = i;
                }
            }
        }

        return mejorMovimiento;
    }

   
    
}